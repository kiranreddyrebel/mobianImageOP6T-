/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_GENERIC_FCNTL_H
#define _ASM_GENERIC_FCNTL_H

#include <linux/types.h>

/*
 * FMODE_EXEC is 0x20
 * These cannot be used by userspace O_* until internal and external open
 * flags are split.
 * -Eric Paris
 */

/*
 * When introducing new O_* bits, please check its uniqueness in fcntl_init().
 */

#define O_ACCMODE	3
#define O_RDONLY	0
#define O_WRONLY	(1 << 0)
#define O_RDWR		(1 << 1)
/* (1 << 2) must not be used -- it collides with flags on alpha, sparc */
/* (1 << 3) must not be used -- it collides with flags on alpha, mips, parisc, sparc */
/* (1 << 4) must not be used -- it collides with flags on mips */
/* (1 << 5) is free */
#ifndef O_CREAT
#define O_CREAT		(1 << 6)	/* not fcntl */
#endif
#ifndef O_EXCL
#define O_EXCL		(1 << 7)	/* not fcntl */
#endif
#ifndef O_NOCTTY
#define O_NOCTTY	(1 << 8)	/* not fcntl */
#endif
#ifndef O_TRUNC
#define O_TRUNC		(1 << 9)	/* not fcntl */
#endif
#ifndef O_APPEND
#define O_APPEND	(1 << 10)
#endif
#ifndef O_NONBLOCK
#define O_NONBLOCK	(1 << 11)
#endif
#ifndef O_DSYNC
#define O_DSYNC		(1 << 12)	/* used to be O_SYNC, see below */
#endif
#ifndef FASYNC
#define FASYNC		(1 << 13)	/* fcntl, for BSD compatibility */
#endif
#ifndef O_DIRECT
#define O_DIRECT	(1 << 14)	/* direct disk access hint */
#endif
#ifndef O_LARGEFILE
#define O_LARGEFILE	(1 << 15)
#endif
#ifndef O_DIRECTORY
#define O_DIRECTORY	(1 << 16)	/* must be a directory */
#endif
#ifndef O_NOFOLLOW
#define O_NOFOLLOW	(1 << 17)	/* don't follow links */
#endif
#ifndef O_NOATIME
#define O_NOATIME	(1 << 18)
#endif
#ifndef O_CLOEXEC
#define O_CLOEXEC	(1 << 19)	/* set close_on_exec */
#endif

/*
 * Before Linux 2.6.33 only O_DSYNC semantics were implemented, but using
 * the O_SYNC flag.  We continue to use the existing numerical value
 * for O_DSYNC semantics now, but using the correct symbolic name for it.
 * This new value is used to request true Posix O_SYNC semantics.  It is
 * defined in this strange way to make sure applications compiled against
 * new headers get at least O_DSYNC semantics on older kernels.
 *
 * This has the nice side-effect that we can simply test for O_DSYNC
 * wherever we do not care if O_DSYNC or O_SYNC is used.
 *
 * Note: __O_SYNC must never be used directly.
 */
#ifndef O_SYNC
#define __O_SYNC	(1 << 20)
#define O_SYNC		(__O_SYNC|O_DSYNC)
#endif

#ifndef O_PATH
#define O_PATH		(1 << 21)
#endif

#ifndef __O_TMPFILE
#define __O_TMPFILE	(1 << 22)
#endif

#ifndef O_EMPTYPATH
#define O_EMPTYPATH	(1 << 26)	/* allow empty path */
#endif

/* a horrid kludge trying to make sure that this will fail on old kernels */
#define O_TMPFILE (__O_TMPFILE | O_DIRECTORY)

#ifndef O_NDELAY
#define O_NDELAY	O_NONBLOCK
#endif

/* (1 << 23) must not be used -- it collides with flags on alpha, parisc, sparc */
/* (1 << 24) must not be used -- it collides with flags on alpha, sparc */
/* (1 << 25) must not be used -- it collides with flags on sparc */

#define F_DUPFD		0	/* dup */
#define F_GETFD		1	/* get close_on_exec */
#define F_SETFD		2	/* set/clear close_on_exec */
#define F_GETFL		3	/* get file->f_flags */
#define F_SETFL		4	/* set file->f_flags */
#ifndef F_GETLK
#define F_GETLK		5
#define F_SETLK		6
#define F_SETLKW	7
#endif
#ifndef F_SETOWN
#define F_SETOWN	8	/* for sockets. */
#define F_GETOWN	9	/* for sockets. */
#endif
#ifndef F_SETSIG
#define F_SETSIG	10	/* for sockets. */
#define F_GETSIG	11	/* for sockets. */
#endif

#if __BITS_PER_LONG == 32 || defined(__KERNEL__)
#ifndef F_GETLK64
#define F_GETLK64	12	/*  using 'struct flock64' */
#define F_SETLK64	13
#define F_SETLKW64	14
#endif
#endif /* __BITS_PER_LONG == 32 || defined(__KERNEL__) */

#ifndef F_SETOWN_EX
#define F_SETOWN_EX	15
#define F_GETOWN_EX	16
#endif

#ifndef F_GETOWNER_UIDS
#define F_GETOWNER_UIDS	17
#endif

/*
 * Open File Description Locks
 *
 * Usually record locks held by a process are released on *any* close and are
 * not inherited across a fork().
 *
 * These cmd values will set locks that conflict with process-associated
 * record  locks, but are "owned" by the open file description, not the
 * process. This means that they are inherited across fork() like BSD (flock)
 * locks, and they are only released automatically when the last reference to
 * the the open file against which they were acquired is put.
 */
#define F_OFD_GETLK	36
#define F_OFD_SETLK	37
#define F_OFD_SETLKW	38

#define F_OWNER_TID	0
#define F_OWNER_PID	1
#define F_OWNER_PGRP	2

struct f_owner_ex {
	int	type;
	__kernel_pid_t	pid;
};

/* for F_[GET|SET]FL */
#define FD_CLOEXEC	1	/* actually anything with low bit set goes */

/* for posix fcntl() and lockf() */
#ifndef F_RDLCK
#define F_RDLCK		0
#define F_WRLCK		1
#define F_UNLCK		2
#endif

/* for old implementation of bsd flock () */
#ifndef F_EXLCK
#define F_EXLCK		4	/* or 3 */
#define F_SHLCK		8	/* or 4 */
#endif

/* operations for bsd flock(), also used by the kernel implementation */
#define LOCK_SH		1	/* shared lock */
#define LOCK_EX		2	/* exclusive lock */
#define LOCK_NB		4	/* or'd with one of the above to prevent
				   blocking */
#define LOCK_UN		8	/* remove lock */

/*
 * LOCK_MAND support has been removed from the kernel. We leave the symbols
 * here to not break legacy builds, but these should not be used in new code.
 */
#define LOCK_MAND	32	/* This is a mandatory flock ... */
#define LOCK_READ	64	/* which allows concurrent read operations */
#define LOCK_WRITE	128	/* which allows concurrent write operations */
#define LOCK_RW		192	/* which allows concurrent read & write ops */

#define F_LINUX_SPECIFIC_BASE	1024

#ifndef HAVE_ARCH_STRUCT_FLOCK
struct flock {
	short	l_type;
	short	l_whence;
	__kernel_off_t	l_start;
	__kernel_off_t	l_len;
	__kernel_pid_t	l_pid;
#ifdef	__ARCH_FLOCK_EXTRA_SYSID
	__ARCH_FLOCK_EXTRA_SYSID
#endif
#ifdef	__ARCH_FLOCK_PAD
	__ARCH_FLOCK_PAD
#endif
};

struct flock64 {
	short  l_type;
	short  l_whence;
	__kernel_loff_t l_start;
	__kernel_loff_t l_len;
	__kernel_pid_t  l_pid;
#ifdef	__ARCH_FLOCK64_PAD
	__ARCH_FLOCK64_PAD
#endif
};
#endif /* HAVE_ARCH_STRUCT_FLOCK */

#endif /* _ASM_GENERIC_FCNTL_H */
